Courier Management:
=========================================================

Go to Setting / apps and search "Courier Management" and Install

And, you are done with installation. Congratulations!